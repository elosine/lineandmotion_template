// [ goTime, playerNum, eventType, eventSpecificData]
// EVENT TYPES: 0-beat(neonMagenta); 1-notation(sea_green); 2-pitches(white);
// 3-stop(red); 4-cres(purple); 5-playSamps; 6-16ths(lightPink); 7-halfNotes(turquoise);
// 8-events(seaGreen)
var eventSet = [];
var ogInsts = [];

// function singleTempoGenerator_numBeats(tempo, instNum, startTime, numBeats, a_btIncAr) {
singleTempoGenerator_numBeats(60, 0, 0, 100, []);











/*
NOTES:


*/
